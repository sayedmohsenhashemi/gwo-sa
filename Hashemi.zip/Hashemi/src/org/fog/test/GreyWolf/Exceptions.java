package org.fog.test.GreyWolf;

@SuppressWarnings("serial")
public class Exceptions extends RuntimeException {

}
