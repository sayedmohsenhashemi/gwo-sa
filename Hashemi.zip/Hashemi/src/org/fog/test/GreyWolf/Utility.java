package org.fog.test.GreyWolf;

interface Comparator{
	boolean compare(double a, double b);
}
