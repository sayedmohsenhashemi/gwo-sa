package org.fog.test.AntColony;

public class PlanetLabConstants {

	public final static int NUMBER_OF_HOSTS = 800;

}
