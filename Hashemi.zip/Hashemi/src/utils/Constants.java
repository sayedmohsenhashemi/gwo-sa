package utils;

public class Constants {
    public static final int NO_OF_TASKS = 900;  
    public static final int NO_OF_DATA_CENTERS = 20;  
    public static final int POPULATION_SIZE = 40;  
	public final static int NUMBER_OF_Container = 500;
	public final static double SCHEDULING_INTERVAL = 300;
	public final static int NUMBER_OF_Nodes = 5000;


}
